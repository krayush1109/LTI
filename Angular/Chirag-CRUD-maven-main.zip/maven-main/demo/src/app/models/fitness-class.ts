export interface FitnessClass {
    id?: string;
    name: string;
    description: string;
    instructor: string;
    date: string;
    time: string;
    duration: number;
    capacity: number;
    availableSlots: number;
   }
   